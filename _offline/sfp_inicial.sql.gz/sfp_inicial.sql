-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 04, 2012 at 12:33 AM
-- Server version: 5.5.22
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sfp`
--

-- --------------------------------------------------------

--
-- Table structure for table `acessos`
--

CREATE TABLE IF NOT EXISTS `acessos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `usuario_id` int(11) NOT NULL DEFAULT '0',
  `dt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `acessos`
--

INSERT INTO `acessos` (`id`, `ip`, `user_agent`, `usuario_id`, `dt`) VALUES
(60, '127.0.0.1', '', 13, '2012-05-04 00:07:07'),
(61, '127.0.0.1', '', 13, '2012-05-04 00:08:08'),
(62, '127.0.0.1', '', 13, '2012-05-04 00:08:56');

-- --------------------------------------------------------

--
-- Table structure for table `bancos`
--

CREATE TABLE IF NOT EXISTS `bancos` (
  `id` varchar(5) NOT NULL DEFAULT '',
  `nome` varchar(100) NOT NULL DEFAULT '',
  `descricao` varchar(255) NOT NULL DEFAULT '',
  `dt_cadastro` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dt_alteracao` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `beneficios`
--

CREATE TABLE IF NOT EXISTS `beneficios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titular` varchar(255) NOT NULL DEFAULT '',
  `tipo` varchar(255) NOT NULL DEFAULT '',
  `bandeira` varchar(50) NOT NULL DEFAULT '',
  `numero` varchar(16) NOT NULL DEFAULT '',
  `validade` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `saldo` double(10,2) NOT NULL DEFAULT '0.00',
  `dt_cadastro` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dt_alteracao` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Table structure for table `categorias`
--

CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL DEFAULT '',
  `dt_cadastro` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dt_alteracao` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `contas`
--

CREATE TABLE IF NOT EXISTS `contas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titular` varchar(255) NOT NULL DEFAULT '',
  `tipo` enum('c','p','cp') NOT NULL DEFAULT 'c',
  `banco_id` varchar(5) NOT NULL DEFAULT '',
  `num_agencia` varchar(5) NOT NULL DEFAULT '',
  `ag_digito` varchar(2) NOT NULL DEFAULT '',
  `num_conta` varchar(8) NOT NULL DEFAULT '',
  `conta_digito` varchar(2) NOT NULL DEFAULT '',
  `saldo` double(10,2) NOT NULL DEFAULT '0.00',
  `limite` double(10,2) NOT NULL DEFAULT '0.00',
  `dt_cadastro` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dt_alteracao` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `creditos`
--

CREATE TABLE IF NOT EXISTS `creditos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titular` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `bandeira` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `conta_id` int(11) NOT NULL DEFAULT '0',
  `numero` varchar(16) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `validade` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `vencimento` int(2) NOT NULL DEFAULT '1',
  `limite_reais` double(10,2) NOT NULL DEFAULT '0.00',
  `limite_saque_reais` double(10,2) NOT NULL DEFAULT '0.00',
  `limite_dolar` double(10,2) NOT NULL DEFAULT '0.00',
  `limite_saque_dolar` double(10,2) NOT NULL DEFAULT '0.00',
  `dt_cadastro` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dt_alteracao` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `lancamentos`
--

CREATE TABLE IF NOT EXISTS `lancamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL DEFAULT '',
  `descricao` varchar(255) NOT NULL DEFAULT '',
  `categoria_id` int(11) NOT NULL DEFAULT '0',
  `imagem` varchar(255) NOT NULL DEFAULT '',
  `tipo` enum('c','d') NOT NULL DEFAULT 'd',
  `meio` enum('credito','conta','beneficio') NOT NULL DEFAULT 'conta',
  `valor` double(10,2) NOT NULL DEFAULT '0.00',
  `dt_cadastro` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dt_alteracao` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `metodos`
--

CREATE TABLE IF NOT EXISTS `metodos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `classe` varchar(50) NOT NULL DEFAULT '',
  `metodo` varchar(50) NOT NULL DEFAULT '',
  `apelido` varchar(255) NOT NULL DEFAULT '',
  `privado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=90 ;

--
-- Dumping data for table `metodos`
--

INSERT INTO `metodos` (`id`, `classe`, `metodo`, `apelido`, `privado`) VALUES
(36, 'usuario', 'meusdados', 'usuario/meusdados', 1),
(37, 'usuario', 'index', 'usuario/index', 1),
(38, 'usuario', 'minhasenha', 'usuario/minhasenha', 1),
(39, 'usuario', 'grava_minhasenha', 'usuario/grava_minhasenha', 1),
(40, 'usuario', 'grava_meusdados', 'usuario/grava_meusdados', 1),
(41, 'usuario', 'novo', 'usuario/novo', 1),
(42, 'usuario', 'alterar', 'usuario/alterar', 1),
(43, 'usuario', 'novasenha', 'usuario/novasenha', 1),
(44, 'usuario', 'grava_novo', 'usuario/grava_novo', 1),
(45, 'usuario', 'grava_dados', 'usuario/grava_dados', 1),
(46, 'usuario', 'grava_novasenha', 'usuario/grava_novasenha', 1),
(47, 'usuario', 'remover', 'usuario/remover', 1),
(48, 'usuario', 'permissoes', 'usuario/permissoes', 1),
(49, 'metodo', 'alterar', 'metodo/alterar', 1),
(50, 'metodo', 'grava_dados', 'metodo/grava_dados', 1),
(51, 'lancamento', 'index', 'lancamento/index', 1),
(52, 'lancamento', 'alterar', 'lancamento/alterar', 1),
(53, 'lancamento', 'grava_dados', 'lancamento/grava_dados', 1),
(54, 'lancamento', 'grava_novo', 'lancamento/grava_novo', 1),
(55, 'lancamento', 'novo', 'lancamento/novo', 1),
(56, 'lancamento', 'remover', 'lancamento/remover', 1),
(57, 'credito', 'index', 'credito/index', 1),
(58, 'credito', 'alterar', 'credito/alterar', 1),
(59, 'credito', 'grava_dados', 'credito/grava_dados', 1),
(60, 'credito', 'grava_novo', 'credito/grava_novo', 1),
(61, 'credito', 'novo', 'credito/novo', 1),
(62, 'credito', 'remover', 'credito/remover', 1),
(63, 'conta', 'index', 'conta/index', 1),
(64, 'conta', 'alterar', 'conta/alterar', 1),
(65, 'conta', 'grava_dados', 'conta/grava_dados', 1),
(66, 'conta', 'grava_nova', 'conta/grava_nova', 1),
(67, 'conta', 'nova', 'conta/nova', 1),
(68, 'conta', 'remover', 'conta/remover', 1),
(69, 'categoria', 'index', 'categoria/index', 1),
(70, 'categoria', 'alterar', 'categoria/alterar', 1),
(71, 'categoria', 'grava_dados', 'categoria/grava_dados', 1),
(72, 'categoria', 'grava_nova', 'categoria/grava_nova', 1),
(73, 'categoria', 'nova', 'categoria/nova', 1),
(74, 'categoria', 'remover', 'categoria/remover', 1),
(75, 'cadastro', 'index', 'cadastro/index', 1),
(76, 'cadastro', 'cadastro', 'cadastro/cadastro', 1),
(77, 'beneficio', 'index', 'beneficio/index', 1),
(78, 'beneficio', 'alterar', 'beneficio/alterar', 1),
(79, 'beneficio', 'grava_dados', 'beneficio/grava_dados', 1),
(80, 'beneficio', 'grava_novo', 'beneficio/grava_novo', 1),
(81, 'beneficio', 'novo', 'beneficio/novo', 1),
(82, 'beneficio', 'remover', 'beneficio/remover', 1),
(83, 'usuario', 'grava_permissoes', 'usuario/grava_permissoes', 1),
(84, 'banco', 'index', 'banco/index', 1),
(85, 'banco', 'alterar', 'banco/alterar', 1),
(86, 'banco', 'grava_dados', 'banco/grava_dados', 1),
(87, 'banco', 'grava_novo', 'banco/grava_novo', 1),
(88, 'banco', 'novo', 'banco/novo', 1),
(89, 'banco', 'remover', 'banco/remover', 1);

-- --------------------------------------------------------

--
-- Table structure for table `permissoes`
--

CREATE TABLE IF NOT EXISTS `permissoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `metodo_id` int(11) NOT NULL DEFAULT '0',
  `usuario_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=803 ;

--
-- Dumping data for table `permissoes`
--

INSERT INTO `permissoes` (`id`, `metodo_id`, `usuario_id`) VALUES
(796, 37, 13),
(795, 83, 13),
(794, 44, 13),
(793, 46, 13),
(792, 39, 13),
(791, 40, 13),
(790, 45, 13),
(789, 42, 13),
(788, 50, 13),
(787, 49, 13),
(786, 56, 13),
(785, 55, 13),
(784, 51, 13),
(783, 54, 13),
(782, 53, 13),
(781, 52, 13),
(780, 62, 13),
(779, 61, 13),
(778, 57, 13),
(777, 60, 13),
(776, 59, 13),
(775, 58, 13),
(774, 68, 13),
(773, 67, 13),
(772, 63, 13),
(771, 66, 13),
(770, 65, 13),
(769, 64, 13),
(768, 74, 13),
(767, 73, 13),
(766, 69, 13),
(765, 72, 13),
(764, 71, 13),
(763, 70, 13),
(762, 75, 13),
(761, 76, 13),
(760, 82, 13),
(759, 81, 13),
(758, 77, 13),
(757, 80, 13),
(756, 79, 13),
(755, 78, 13),
(754, 89, 13),
(753, 88, 13),
(752, 84, 13),
(751, 87, 13),
(750, 86, 13),
(749, 85, 13),
(797, 36, 13),
(798, 38, 13),
(799, 43, 13),
(800, 41, 13),
(801, 48, 13),
(802, 47, 13);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(100) NOT NULL DEFAULT '',
  `senha` varchar(150) NOT NULL DEFAULT '',
  `nome` varchar(200) NOT NULL DEFAULT '',
  `email` varchar(150) NOT NULL DEFAULT '',
  `dt_cadastro` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dt_alteracao` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `senha`, `nome`, `email`, `dt_cadastro`, `dt_alteracao`) VALUES
(13, 'wsilva', '9c20106ae3a2b0e2bbe768fa03413efc', 'Wellington F. Silva', 'wsilva@usp.br', '2012-05-04 00:06:49', '2012-05-04 00:30:44');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
